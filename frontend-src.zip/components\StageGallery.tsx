import React from 'react';

type Stage = 'inspiration' | 'design' | 'modeling' | 'rendering';

interface Item {
  id: string;
  stage?: Stage;
  title?: string;
  description?: string;
  actor?: { address: string; name?: string };
  timestamp?: string;
  assetUrl?: string;
  metadata?: any;
}

interface Props {
  title?: string;
  items?: Item[];
  projects?: any[];
  stage: Stage;
  selectable?: boolean;
  selectedId?: string;
  onSelect?: (id: string) => void;
  onDerive?: (parentId: string) => void;
  onUpdate?: (id: string) => void;
  onProjectClick?: (project: any) => void;
}

function toImage(url?: string): string {
  if (!url) return 'https://placehold.co/300x200/png';
  if (url.startsWith('ipfs://')) {
    const hash = url.replace('ipfs://', '');
    if (!hash || hash.toUpperCase().includes('FAKE_HASH')) {
      return 'https://placehold.co/300x200/png';
    }
    return `https://ipfs.io/ipfs/${hash}`;
  }
  return url;
}

const StageGallery: React.FC<Props> = ({ 
  title, 
  items, 
  projects, 
  stage, 
  selectable, 
  selectedId, 
  onSelect, 
  onDerive, 
  onUpdate, 
  onProjectClick 
}) => {
  // 使用 projects 或 items，优先使用 projects
  const displayItems = projects || items || [];
  
  return (
    <section className={title ? "mt-8" : ""}>
      {title && (
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-semibold">{title}</h2>
          <span className="inline-flex px-2 py-1 text-xs rounded bg-gray-100 text-gray-700">{stage}</span>
        </div>
      )}
      <div className="mt-4 grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {displayItems.map((item) => {
          const img = toImage(item.assetUrl || item.metadata?.image || item.image);
          const name = item.title || item.metadata?.title || item.name || item.id;
          const isSel = selectable && selectedId === item.id;
          
          return (
            <div key={item.id} className={`relative group rounded border overflow-hidden hover:shadow transition cursor-pointer ${isSel ? 'ring-2 ring-indigo-500' : ''}`}>
              <div 
                className="block"
                onClick={() => onProjectClick ? onProjectClick(item) : window.location.href = `/nft/${item.id}`}
              >
                <img src={img} alt={name} className="w-full h-28 object-cover" />
              </div>
              <div className="p-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-medium truncate max-w-[70%]">{name}</span>
                  <span className="text-[10px] px-1 py-[1px] rounded bg-indigo-50 text-indigo-700">{stage}</span>
                </div>
                {(item.actor?.name || item.description) && (
                  <p className="mt-1 text-[11px] text-gray-600 truncate">
                    {item.actor?.name || item.description}
                  </p>
                )}
              </div>
              {selectable && (
                <button
                  type="button"
                  className="absolute top-2 right-2 text-xs px-2 py-1 rounded bg-white/80 hover:bg-white border"
                  onClick={(e) => { e.stopPropagation(); onSelect && onSelect(item.id); }}
                >{isSel ? '已选择' : '选择'}</button>
              )}
              {onUpdate && (
                <button
                  type="button"
                  className="absolute bottom-2 left-2 text-xs px-2 py-1 rounded bg-white/80 hover:bg-white border"
                  onClick={(e) => { e.preventDefault(); e.stopPropagation(); onUpdate(item.id); }}
                >更新</button>
              )}
              {onDerive && (
                <button
                  type="button"
                  className="absolute bottom-2 right-2 text-xs px-2 py-1 rounded bg-indigo-600 text-white hover:bg-indigo-700"
                  onClick={(e) => { e.preventDefault(); e.stopPropagation(); onDerive(item.id); }}
                >派生</button>
              )}
            </div>
          );
        })}
        {displayItems.length === 0 && (
          <div className="col-span-full text-gray-600 text-sm">暂无内容</div>
        )}
      </div>
    </section>
  );
};

export default StageGallery;