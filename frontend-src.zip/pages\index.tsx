import React from 'react';
import Head from 'next/head';
import Link from 'next/link';
import Header from '../components/Header';
import Footer from '../components/Footer';
import NFTCard from '../components/NFTCard';
import { listByStage } from '../services/api';

interface NFT {
  id: string;
  title: string;
  description: string;
  imageUrl: string;
}

const Home: React.FC = () => {
  const [nfts, setNfts] = React.useState<NFT[]>([]);
  const [loading, setLoading] = React.useState<boolean>(true);
  const [error, setError] = React.useState<string>('');

  const fetchNFTs = async () => {
    try {
      setLoading(true);
      const result = await listByStage('rendering');
      if (result.success) {
        const items = (result.items || []).map((it: any) => ({
          id: it.id,
          title: it.title || it.metadata?.title || `渲染 #${it.id}`,
          description: it.description || it.metadata?.description || '',
          imageUrl: it.image || it.metadata?.image || 'https://placehold.co/600x400/png',
        }));
        setNfts(items);
        setError('');
      } else {
        setError('加载 NFT 失败');
      }
    } catch (err) {
      console.error(err);
      setError('服务器连接错误');
    } finally {
      setLoading(false);
    }
  };

  React.useEffect(() => {
    fetchNFTs();
  }, []);

  return (
    <div>
      <Head>
        <title>动态 NFT 首页</title>
        <meta name="description" content="使用 React + Tailwind 打造简洁现代的动态 NFT 首页。" />
      </Head>
      <Header />
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        {/* Hero */}
        <section className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 text-white">
          <div className="px-6 py-12 sm:px-10 sm:py-16 lg:px-16 lg:py-20">
            <h1 className="text-2xl sm:text-3xl lg:text-4xl font-bold tracking-tight">探索动态 NFT 的创作与展示</h1>
            <p className="mt-3 text-sm sm:text-base lg:text-lg text-white/90 max-w-2xl">
              从灵感到设计、建模与渲染，完整的链上创作流程，一站式呈现。
            </p>
            <div className="mt-6 flex flex-wrap gap-3">
              <Link href="/" className="inline-flex items-center rounded-md bg-white text-indigo-700 font-medium px-4 py-2 shadow hover:bg-indigo-50 transition">
                开始浏览
              </Link>
              <Link href="/inspiration" className="inline-flex items-center rounded-md bg-indigo-700 text-white font-medium px-4 py-2 shadow hover:bg-indigo-800 transition">
                提交灵感
              </Link>
            </div>
          </div>
        </section>

        {/* Controls */}
        <section className="mt-8 flex items-center gap-4">
          <button
            className="px-4 py-2 rounded bg-blue-600 text-white hover:bg-blue-700 disabled:opacity-50"
            onClick={fetchNFTs}
            disabled={loading}
          >
            {loading ? '正在加载...' : '刷新内容'}
          </button>
          {error && <p className="text-red-500">{error}</p>}
        </section>

        {/* Grid */}
        {loading && <p className="mt-6 text-gray-600">正在加载 NFT...</p>}
        <section className="mt-6">
          <div className="flex items-center justify-between">
            <h2 className="text-lg sm:text-xl font-semibold text-gray-900">精选作品（渲染阶段）</h2>
            <span className="text-sm text-gray-500">共 {nfts.length} 项</span>
          </div>
          <div className="mt-6 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {nfts.map((nft) => (
              <Link href={`/nft/${nft.id}`} key={nft.id} className="block">
                <NFTCard
                  id={nft.id}
                  imageUrl={nft.imageUrl}
                  title={nft.title}
                  description={nft.description}
                />
              </Link>
            ))}
          </div>
          {!loading && nfts.length === 0 && !error && (
            <p className="mt-4 text-gray-600">暂无 NFT。可以前往灵感页提交你的创意。</p>
          )}
        </section>
      </main>
      <Footer />
    </div>
  );
};

export default Home;