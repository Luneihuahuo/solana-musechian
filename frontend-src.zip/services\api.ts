// 在 Node/SSR 环境提供 fetch polyfill（跨环境统一）
import 'cross-fetch/polyfill';

// API服务用于与后端交互
const API_URL = process.env.NEXT_PUBLIC_API_URL ?? 'http://localhost:5000';

// 通用：健壮的 JSON 获取
const fetchJSON = async (url: string) => {
  const resp = await fetch(url);
  const ct = resp.headers.get('content-type') || '';
  if (!resp.ok) {
    const text = await resp.text().catch(() => '');
    throw new Error(`HTTP ${resp.status} at ${url}: ${text?.slice(0, 200)}`);
  }
  if (!ct.includes('application/json')) {
    const text = await resp.text().catch(() => '');
    throw new Error(`Non-JSON response at ${url}. Content-Type: ${ct}. Snippet: ${text?.slice(0, 200)}`);
  }
  return resp.json();
};

// 获取NFT元数据（注意：后端路由在 /api/metadata/:id 或 /api/onchain/nft/:id）
export const getNFTMetadata = async (id: string) => {
  try {
    const response = await fetch(`${API_URL}/api/onchain/nft/${id}`);
    if (!response.ok) {
      throw new Error('Failed to fetch NFT metadata');
    }
    return await response.json();
  } catch (error) {
    console.error('Error fetching NFT metadata:', error);
    return null;
  }
};

// 获取所有NFT
export const getAllNFTs = async () => {
  try {
    // 模拟获取多个NFT的数据（使用外部占位图，避免本地图片不存在）
    const mockNFTs = [
      { id: '1', title: 'Dynamic NFT 1', description: '3D Model NFT', imageUrl: 'https://placehold.co/600x400/png' },
      { id: '2', title: 'Dynamic NFT 2', description: 'Interactive NFT', imageUrl: 'https://placehold.co/600x400/png' },
      { id: '3', title: 'Dynamic NFT 3', description: 'Animated NFT', imageUrl: 'https://placehold.co/600x400/png' }
    ];
    return { success: true, nfts: mockNFTs };
  } catch (error) {
    console.error('Error fetching all NFTs:', error);
    return { success: false, nfts: [] };
  }
};

// 获取单个NFT详情（链上基本元数据）
export const getOnchainNFT = async (id: string) => {
  try {
    // 改为使用本地 Next API 路由，确保与模拟数据一致
    const m = await fetchJSON(`/api/onchain/nft/${id}`);
    // 规范化元数据，确保前端渲染字段存在
    return {
      id,
      name: m?.name ?? `NFT #${id}`,
      image: m?.image ?? 'https://placehold.co/600x400/png',
      description: m?.description ?? '',
      creator: m?.creator ?? null,
      attributes: Array.isArray(m?.attributes) ? m.attributes : [],
    };
  } catch (error) {
    console.error('Error fetching onchain NFT:', error);
    return null;
  }
};

// 获取NFT演化历史（灵感->设计->模型->渲染）
export const getNFTEvolutionHistory = async (id: string) => {
  try {
    // 改为使用本地 Next API 路由，统一返回拓展的模拟数据
    return await fetchJSON(`/api/onchain/nft/${id}/history`);
  } catch (error) {
    console.error('Error fetching NFT evolution history:', error);
    return { success: false, history: [] };
  }
};

// 新增：获取NFT演化树（树状结构）
export const getNFTEvolutionTree = async (id: string) => {
  try {
    // 改为使用本地 Next API 路由，统一返回拓展的模拟数据
    return await fetchJSON(`/api/onchain/nft/${id}/tree`);
  } catch (error) {
    console.error('Error fetching NFT evolution tree:', error);
    return { success: false, tree: null };
  }
};

// 更新NFT元数据（统一路由：/api/onchain/update-nft）
export const updateNFTMetadata = async (nftId: string, newData: any) => {
  try {
    const response = await fetch(`${API_URL}/api/onchain/update-nft`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ nftId, newData }),
    });
    if (!response.ok) throw new Error('Failed to update NFT metadata');
    return await response.json();
  } catch (error) {
    console.error('Error updating NFT metadata:', error);
    return { success: false, error: 'Failed to update NFT' };
  }
};

// 新增：四阶段更新（灵感/设计/建模/渲染）支持直接 uri 或 metadata
export const postStageUpdate = async (
  id: string,
  stage: 'inspiration' | 'design' | 'modeling' | 'rendering',
  payload: { ownerAddress: string; uri?: string; metadata?: any }
) => {
  try {
    const response = await fetch(`${API_URL}/api/onchain/nft/${id}/${stage}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    if (!response.ok) {
      const errText = await response.text().catch(() => '');
      throw new Error(`Failed to post ${stage}: ${errText}`);
    }
    return await response.json();
  } catch (error) {
    console.error(`Error posting ${stage}:`, error);
    return { success: false, error: String(error) };
  }
};

// 新增：项目创建（灵感页面铸造根NFT）
export const createProject = async (payload: { ownerAddress: string; metadata?: any; uri?: string }) => {
  try {
    const response = await fetch(`/api/onchain/projects`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    if (!response.ok) {
      const text = await response.text().catch(() => '');
      throw new Error(`Failed to create project: ${text}`);
    }
    return await response.json();
  } catch (error) {
    console.error('Error creating project:', error);
    return { success: false, error: String(error) };
  }
};

// 新增：项目列表（所有根灵感NFT）
export const listProjects = async () => {
  try {
    const r = await fetch(`/api/onchain/stage/inspiration`);
    if (!r.ok) throw new Error('Failed to list projects');
    const j = await r.json();
    return { success: true, items: j.items || [] };
  } catch (error) {
    console.error('Error listing projects:', error);
    return { success: false, items: [] };
  }
};

// 新增：按阶段列表
export const listByStage = async (stage: 'inspiration' | 'design' | 'modeling' | 'rendering') => {
  try {
    const r = await fetch(`/api/onchain/stage/${stage}`);
    if (!r.ok) throw new Error('Failed to list by stage');
    const j = await r.json();
    return { success: true, items: j.items || [] };
  } catch (error) {
    console.error('Error listing by stage:', error);
    return { success: false, items: [] };
  }
};

// 新增：在父节点下创建派生NFT（设计/建模/渲染）
export const deriveChildNFT = async (
  parentId: string,
  stage: 'design' | 'modeling' | 'rendering',
  payload: { ownerAddress: string; metadata?: any; uri?: string }
) => {
  try {
    const response = await fetch(`/api/onchain/nft/${parentId}/derive`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ stage, ...payload }),
    });
    if (!response.ok) {
      const text = await response.text().catch(() => '');
      throw new Error(`Failed to derive ${stage}: ${text}`);
    }
    return await response.json();
  } catch (error) {
    console.error(`Error deriving ${stage}:`, error);
    return { success: false, error: String(error) };
  }
};

export default {
  getNFTMetadata,
  getAllNFTs,
  getOnchainNFT,
  getNFTEvolutionHistory,
  getNFTEvolutionTree,
  updateNFTMetadata,
  postStageUpdate,
  createProject,
  listProjects,
  listByStage,
  deriveChildNFT,
};