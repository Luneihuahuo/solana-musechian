import React, { useEffect, useRef } from 'react';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader';
import { Scene, PerspectiveCamera, WebGLRenderer } from 'three';

const Viewer3D: React.FC<{ modelUrl?: string }> = ({ modelUrl }) => {
    const mountRef = useRef<HTMLDivElement | null>(null);

    if (!modelUrl) {
        return <div className="viewer-3d flex items-center justify-center text-gray-500">No model loaded</div>;
    }

    useEffect(() => {
        const scene = new Scene();
        const camera = new PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
        const renderer = new WebGLRenderer();
        
        renderer.setSize(window.innerWidth, window.innerHeight);
        if (mountRef.current) {
            mountRef.current.appendChild(renderer.domElement);
        }

        const loader = new GLTFLoader();
        loader.load(modelUrl, (gltf: any) => {
            scene.add(gltf.scene);
            renderer.render(scene, camera);
        });

        camera.position.z = 5;

        const animate = () => {
            requestAnimationFrame(animate);
            renderer.render(scene, camera);
        };

        animate();

        return () => {
            if (mountRef.current) {
                mountRef.current.removeChild(renderer.domElement);
            }
        };
    }, [modelUrl]);

    return <div ref={mountRef} />;
};

export default Viewer3D;