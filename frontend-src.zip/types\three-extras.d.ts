declare module 'three';
declare module 'three/examples/jsm/loaders/GLTFLoader';