import React from 'react';

const Footer: React.FC = () => {
    return (
        <footer className="text-center py-5 bg-gray-50 border-t">
            <p>&copy; {new Date().getFullYear()} Solana Dynamic NFT Project. All rights reserved.</p>
            <p>
                <a href="/privacy-policy">Privacy Policy</a> | <a href="/terms-of-service">Terms of Service</a>
            </p>
        </footer>
    );
};

export default Footer;