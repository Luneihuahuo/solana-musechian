import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/router';
import Header from '../components/Header';
import Footer from '../components/Footer';
import StageGallery from '../components/StageGallery';
import ProjectEntry from '../components/ProjectEntry';
import { listByStage } from '../services/api';

const ModelingPage: React.FC = () => {
  const [modelingProjects, setModelingProjects] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchModelingProjects();
  }, []);

  const fetchModelingProjects = async () => {
    try {
      setLoading(true);
      // 改为使用站内 API 路由，避免跨域与端口问题
      const result = await listByStage('modeling');
      setModelingProjects(result.items || []);
    } catch (error) {
      console.error('Error fetching modeling projects:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleRefresh = () => {
    fetchModelingProjects();
  };

  const router = useRouter();
  const items = modelingProjects.map((p: any) => ({
    id: p.id,
    title: p.title,
    description: p.description,
    assetUrl: p.assetUrl || p.image_url || p.metadata?.image,
  }));

  // 计算每个项目的NFT数量（建模阶段）
  const getProjectNFTCount = async (projectId: string) => {
    try {
      const response = await fetch(`http://localhost:3001/api/nfts?project_id=${projectId}&stage=modeling`);
      const data = await response.json();
      return data.length;
    } catch (error) {
      console.error('Error fetching modeling NFT count:', error);
      return 0;
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header />
        <div className="flex justify-center items-center h-64">
          <div className="text-lg">加载中...</div>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <main className="container mx-auto px-4 py-8">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-800">建模阶段</h1>
            <p className="text-gray-600 mt-2">
              选择建模项目，查看NFT树状图并继续派生/更新
            </p>
          </div>
          <button
            onClick={handleRefresh}
            className="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors"
          >
            刷新
          </button>
        </div>

        {modelingProjects.length === 0 ? (
          <div className="text-center py-12">
            <div className="text-gray-500 text-lg">暂无可用的建模项目</div>
            <p className="text-gray-400 mt-2">请在设计详情页提交作品以进入建模阶段</p>
          </div>
        ) : (
          <StageGallery
            title="建模阶段项目"
            stage="modeling"
            items={items}
            onProjectClick={(item: any) => router.push(`/modeling/${item.id}`)}
          />
        )}
      </main>
      <Footer />
    </div>
  );
};

export default ModelingPage;