import React from 'react';
import Link from 'next/link';
import ConnectWalletModal from './ConnectWalletModal';

const shorten = (addr: string) => addr ? `${addr.slice(0, 6)}...${addr.slice(-4)}` : '';

const Header: React.FC = () => {
    const [walletOpen, setWalletOpen] = React.useState(false);
    const [account, setAccount] = React.useState<string | null>(null);

    return (
        <header className="sticky top-0 z-30 bg-white/90 backdrop-blur border-b">
            <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3 flex items-center justify-between">
                <div className="text-lg font-semibold">动态 NFT 项目</div>
                <ul className="flex flex-wrap gap-4 text-sm text-gray-700 items-center">
                    <li><Link href="/">首页</Link></li>
                    <li><Link href="/">NFT 展示</Link></li>
                    <li><Link href="/inspiration">灵感</Link></li>
                    <li><Link href="/design">设计</Link></li>
                    <li><Link href="/modeling">模型</Link></li>
                    <li><Link href="/rendering">渲染</Link></li>
                    <li>
                        {account ? (
                            <span className="inline-flex items-center rounded-md bg-green-100 text-green-700 px-3 py-1">{shorten(account)}</span>
                        ) : (
                            <button
                                className="inline-flex items-center rounded-md bg-indigo-600 text-white px-3 py-1 hover:bg-indigo-700"
                                onClick={() => setWalletOpen(true)}
                            >
                                连接钱包
                            </button>
                        )}
                    </li>
                </ul>
            </nav>
            <ConnectWalletModal
                open={walletOpen}
                onClose={() => setWalletOpen(false)}
                onConnected={(addr) => setAccount(addr)}
            />
        </header>
    );
};

export default Header;