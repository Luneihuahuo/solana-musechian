import React from 'react';
import { useRouter } from 'next/router';
import Head from 'next/head';
import Header from '../../components/Header';
import Footer from '../../components/Footer';
import { getOnchainNFT, getNFTEvolutionHistory, getNFTEvolutionTree } from '../../services/api';
import EvolutionTree, { EvolutionNode } from '../../components/EvolutionTree';

interface HistoryItem {
  stage: 'inspiration' | 'design' | 'modeling' | 'rendering';
  title: string;
  description: string;
  actor: { address: string; name: string };
  timestamp: string;
  assetUrl?: string;
  tx?: string;
}

const StageBadge: React.FC<{ stage: HistoryItem['stage'] }> = ({ stage }) => {
  const map: Record<HistoryItem['stage'], string> = {
    inspiration: 'bg-yellow-100 text-yellow-800',
    design: 'bg-blue-100 text-blue-800',
    modeling: 'bg-purple-100 text-purple-800',
    rendering: 'bg-green-100 text-green-800',
  };
  return <span className={`inline-flex items-center px-2 py-1 rounded ${map[stage]}`}>{stage}</span>;
};

const NFTDetailPage: React.FC = () => {
  const router = useRouter();
  const { id } = router.query as { id?: string };

  const [meta, setMeta] = React.useState<any>(null);
  const [history, setHistory] = React.useState<HistoryItem[]>([]);
  const [tree, setTree] = React.useState<EvolutionNode | null>(null);
  const [loading, setLoading] = React.useState(true);
  const [error, setError] = React.useState('');

  React.useEffect(() => {
    if (!id) return;
    const load = async () => {
      try {
        setLoading(true);
        const m = await getOnchainNFT(id);
        const h = await getNFTEvolutionHistory(id);
        const t = await getNFTEvolutionTree(id);
        setMeta(m);
        setHistory(h?.history || []);
        setTree((t?.tree as EvolutionNode) || (t as EvolutionNode) || null);
        setError('');
      } catch (e) {
        console.error(e);
        setError('加载详情失败');
      } finally {
        setLoading(false);
      }
    };
    load();
  }, [id]);

  return (
    <div>
      <Head>
        <title>NFT 演化详情</title>
      </Head>
      <Header />
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        <button className="text-sm text-indigo-600 hover:text-indigo-700" onClick={() => router.back()}>
          返回
        </button>

        {loading && <p className="mt-4 text-gray-600">正在加载详情...</p>}
        {error && <p className="mt-4 text-red-600">{error}</p>}

        {meta && (
          <section className="mt-6">
            <div className="flex flex-col md:flex-row gap-6 items-start">
              <img src={meta.image} alt={meta.name} className="w-full md:w-80 rounded shadow" />
              <div className="flex-1">
                <h1 className="text-2xl font-bold">{meta.name}</h1>
                <p className="mt-2 text-gray-700">{meta.description}</p>
                {meta.creator && (
                  <p className="mt-2 text-sm text-gray-600">创作者：{meta.creator.name}（{meta.creator.address}）</p>
                )}
                <div className="mt-3 flex flex-wrap gap-2">
                  {(meta.attributes || []).map((a: any, idx: number) => (
                    <span key={idx} className="px-2 py-1 text-xs rounded bg-gray-100 text-gray-700">
                      {a.trait_type}: {a.value}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </section>
        )}

        {/* 树状演化结构 */}
        <section className="mt-10">
          <h2 className="text-xl font-semibold">演化树状图</h2>
          <div className="mt-4">
            <EvolutionTree root={tree} />
          </div>
        </section>

        {/* 演化时间线 */}
        <section className="mt-10">
          <h2 className="text-xl font-semibold">演化过程</h2>
          <div className="mt-4 space-y-6">
            {history.map((item, idx) => (
              <div key={idx} className="rounded-lg border p-4">
                <div className="flex items-center justify-between">
                  <StageBadge stage={item.stage} />
                  <span className="text-sm text-gray-500">{new Date(item.timestamp).toLocaleString()}</span>
                </div>
                <h3 className="mt-2 text-lg font-medium">{item.title}</h3>
                <p className="mt-1 text-gray-700">{item.description}</p>
                <p className="mt-1 text-sm text-gray-600">参与者：{item.actor.name}（{item.actor.address}）</p>
                {item.assetUrl && (
                  <img className="mt-3 w-full rounded" src={item.assetUrl} alt={item.title} />
                )}
                {item.tx && (
                  <p className="mt-2 text-xs text-gray-500">Tx: {item.tx}</p>
                )}
              </div>
            ))}

            {!loading && history.length === 0 && (
              <p className="text-gray-600">暂无演化数据。</p>
            )}
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
};

export default NFTDetailPage;