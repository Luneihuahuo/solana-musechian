import type { NextApiRequest, NextApiResponse } from 'next';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const { id } = req.query;
  const base = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5000';

  try {
    const r = await fetch(`${base}/api/onchain/nft/${id}/tree`);
    const ct = r.headers.get('content-type') || '';
    if (!r.ok || !ct.includes('application/json')) throw new Error(`Bad response ${r.status}`);
    const data = await r.json();
    return res.status(200).json(data);
  } catch (err) {
    // 返回更完整的演化树：灵感 -> 多个设计 -> 多个建模 -> 多个渲染
    const now = Date.now();
    const iso = (offsetMs: number) => new Date(now - offsetMs).toISOString();
    const root = {
      id: '1',
      parentId: null,
      stage: 'inspiration',
      title: '学院吉祥物灵感',
      description: '为所在学院打造一个独特的吉祥物形象（小NFT）。',
      actor: { address: 'SoA1...', name: 'Alice' },
      timestamp: iso(86_400_000),
      assetUrl: '/images/sample.png',
      tx: 'TX-A1-root',
      children: [
        // 设计分支 A/B/C
        {
          id: '1-1',
          parentId: '1',
          stage: 'design',
          title: '设计图 A（线稿）',
          description: '线稿方案，突出学院的历史与精神。',
          actor: { address: 'SoB1...', name: 'Bob' },
          timestamp: iso(64_800_000),
          assetUrl: '/images/sample.png',
          tx: 'TX-B1-11',
          children: [
            {
              id: '1-1-1',
              parentId: '1-1',
              stage: 'modeling',
              title: '模型 A1（低模）',
              description: '基于线稿A的低模版本，重点匹配比例。',
              actor: { address: 'SoC1...', name: 'Carol' },
              timestamp: iso(43_200_000),
              tx: 'TX-C1-111',
              children: [
                {
                  id: '1-1-1-1',
                  parentId: '1-1-1',
                  stage: 'rendering',
                  title: '渲染 A1-1（首版）',
                  description: '基础灯光与材质，输出预览图。',
                  actor: { address: 'SoD1...', name: 'Dave' },
                  timestamp: iso(28_800_000),
                  assetUrl: '/images/sample.png',
                  tx: 'TX-D1-1111',
                },
              ],
            },
          ],
        },
        {
          id: '1-2',
          parentId: '1',
          stage: 'design',
          title: '设计图 B（彩稿）',
          description: '彩色方案，增加学院标识与主色。',
          actor: { address: 'SoB2...', name: 'Bob' },
          timestamp: iso(57_600_000),
          assetUrl: '/images/sample.png',
          tx: 'TX-B2-12',
          children: [
            {
              id: '1-2-1',
              parentId: '1-2',
              stage: 'modeling',
              title: '模型 B1（中模）',
              description: '彩稿B的中模，补充细节与面数。',
              actor: { address: 'SoC2...', name: 'Carol' },
              timestamp: iso(36_000_000),
              tx: 'TX-C2-121',
              children: [
                {
                  id: '1-2-1-1',
                  parentId: '1-2-1',
                  stage: 'rendering',
                  title: '渲染 B1-1（灯光测试）',
                  description: '测试不同灯光角度与阴影设置。',
                  actor: { address: 'SoD2...', name: 'Dave' },
                  timestamp: iso(21_600_000),
                  assetUrl: '/images/sample.png',
                  tx: 'TX-D2-1211',
                },
              ],
            },
            {
              id: '1-2-2',
              parentId: '1-2',
              stage: 'modeling',
              title: '模型 B2（高模）',
              description: '彩稿B的高模，细化材质与拓扑。',
              actor: { address: 'SoC3...', name: 'Carol' },
              timestamp: iso(33_000_000),
              tx: 'TX-C3-122',
              children: [
                {
                  id: '1-2-2-1',
                  parentId: '1-2-2',
                  stage: 'rendering',
                  title: '渲染 B2-1（材质校准）',
                  description: '校准金属与织物材质，输出测试图。',
                  actor: { address: 'SoD3...', name: 'Dave' },
                  timestamp: iso(18_000_000),
                  assetUrl: '/images/sample.png',
                  tx: 'TX-D3-1221',
                },
              ],
            },
          ],
        },
        {
          id: '1-3',
          parentId: '1',
          stage: 'design',
          title: '设计图 C（极简）',
          description: '极简风格，突出学院主标识。',
          actor: { address: 'SoB3...', name: 'Bob' },
          timestamp: iso(50_400_000),
          assetUrl: '/images/sample.png',
          tx: 'TX-B3-13',
          children: [
            {
              id: '1-3-1',
              parentId: '1-3',
              stage: 'modeling',
              title: '模型 C1（快速迭代）',
              description: '基于极简C的快速建模版本。',
              actor: { address: 'SoC4...', name: 'Carol' },
              timestamp: iso(30_000_000),
              tx: 'TX-C4-131',
              children: [
                {
                  id: '1-3-1-1',
                  parentId: '1-3-1',
                  stage: 'rendering',
                  title: '渲染 C1-1（最终版）',
                  description: '统一灯光材质，输出最终渲染图。',
                  actor: { address: 'SoD4...', name: 'Dave' },
                  timestamp: iso(14_400_000),
                  assetUrl: '/images/sample.png',
                  tx: 'TX-D4-1311',
                },
              ],
            },
          ],
        },
      ],
    };
    const sample = { success: true, id, tree: root };
    return res.status(200).json(sample);
  }
}