import type { NextApiRequest, NextApiResponse } from 'next';

const API_URL = process.env.NEXT_PUBLIC_API_URL ?? 'http://localhost:5000';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const { id } = req.query as { id: string };
  if (!id) return res.status(400).json({ success: false, error: 'Missing id' });
  try {
    if (req.method !== 'POST') {
      res.setHeader('Allow', 'POST');
      return res.status(405).json({ success: false, error: 'Method Not Allowed' });
    }
    const r = await fetch(`${API_URL}/api/onchain/nft/${id}/derive`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(req.body || {}),
    });
    const ct = r.headers.get('content-type') || '';
    if (!r.ok) {
      const errText = await r.text().catch(() => '');
      return res.status(r.status).json({ success: false, error: errText || 'Derive failed' });
    }
    if (ct.includes('application/json')) {
      const data = await r.json();
      return res.status(200).json(data);
    }
    const text = await r.text().catch(() => '');
    return res.status(200).json({ success: true, raw: text });
  } catch (error: any) {
    return res.status(500).json({ success: false, error: String(error) });
  }
}