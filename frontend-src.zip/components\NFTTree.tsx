import React from 'react';

interface NFTNode {
  id: string;
  title: string;
  image_url: string;
  stage: string;
  created_at: string;
  parent_id?: string;
  children?: NFTNode[];
}

interface NFTTreeProps {
  nfts: NFTNode[];
  onNFTClick?: (nft: NFTNode) => void;
  onDerive?: (nft: NFTNode) => void;
  onUpdate?: (nft: NFTNode) => void;
}

const NFTTreeNode: React.FC<{
  nft: NFTNode;
  level: number;
  onNFTClick?: (nft: NFTNode) => void;
  onDerive?: (nft: NFTNode) => void;
  onUpdate?: (nft: NFTNode) => void;
}> = ({ nft, level, onNFTClick, onDerive, onUpdate }) => {
  const getStageColor = (stage: string) => {
    switch (stage) {
      case 'inspiration': return 'bg-purple-100 text-purple-800';
      case 'design': return 'bg-blue-100 text-blue-800';
      case 'modeling': return 'bg-green-100 text-green-800';
      case 'rendering': return 'bg-orange-100 text-orange-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="relative">
      {/* 连接线 */}
      {level > 0 && (
        <div className="absolute -left-8 top-1/2 w-8 h-px bg-gray-300"></div>
      )}
      
      {/* NFT节点 */}
      <div className="flex items-center space-x-4 p-4 bg-white rounded-lg shadow-md border-2 border-gray-200 hover:border-blue-400 transition-colors">
        <img
          src={nft.image_url || '/images/placeholder.png'}
          alt={nft.title}
          className="w-16 h-16 object-cover rounded-lg cursor-pointer"
          onClick={() => onNFTClick?.(nft)}
        />
        
        <div className="flex-1">
          <h4 className="font-semibold text-gray-800 truncate">{nft.title}</h4>
          <div className="flex items-center space-x-2 mt-1">
            <span className={`px-2 py-1 rounded-full text-xs ${getStageColor(nft.stage)}`}>
              {nft.stage}
            </span>
            <span className="text-xs text-gray-500">
              {new Date(nft.created_at).toLocaleDateString()}
            </span>
          </div>
        </div>

        {/* 操作按钮 */}
        <div className="flex space-x-2">
          <button
            onClick={(e) => {
              e.stopPropagation();
              onDerive?.(nft);
            }}
            className="px-3 py-1 bg-blue-500 text-white text-xs rounded hover:bg-blue-600 transition-colors"
          >
            派生
          </button>
          <button
            onClick={(e) => {
              e.stopPropagation();
              onUpdate?.(nft);
            }}
            className="px-3 py-1 bg-green-500 text-white text-xs rounded hover:bg-green-600 transition-colors"
          >
            更新
          </button>
        </div>
      </div>

      {/* 子节点 */}
      {nft.children && nft.children.length > 0 && (
        <div className="ml-8 mt-4 space-y-4">
          {nft.children.map((child) => (
            <NFTTreeNode
              key={child.id}
              nft={child}
              level={level + 1}
              onNFTClick={onNFTClick}
              onDerive={onDerive}
              onUpdate={onUpdate}
            />
          ))}
        </div>
      )}
    </div>
  );
};

const NFTTree: React.FC<NFTTreeProps> = ({ nfts, onNFTClick, onDerive, onUpdate }) => {
  // 构建树形结构
  const buildTree = (nfts: NFTNode[]): NFTNode[] => {
    const nodeMap = new Map<string, NFTNode>();
    const roots: NFTNode[] = [];

    // 创建节点映射
    nfts.forEach(nft => {
      nodeMap.set(nft.id, { ...nft, children: [] });
    });

    // 构建父子关系
    nfts.forEach(nft => {
      const node = nodeMap.get(nft.id)!;
      if (nft.parent_id && nodeMap.has(nft.parent_id)) {
        const parent = nodeMap.get(nft.parent_id)!;
        parent.children!.push(node);
      } else {
        roots.push(node);
      }
    });

    return roots;
  };

  const treeData = buildTree(nfts);

  if (treeData.length === 0) {
    return (
      <div className="text-center py-8 text-gray-500">
        <p>暂无NFT数据</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <h3 className="text-lg font-semibold text-gray-800 mb-4">NFT演化树</h3>
      <div className="space-y-6">
        {treeData.map((root) => (
          <NFTTreeNode
            key={root.id}
            nft={root}
            level={0}
            onNFTClick={onNFTClick}
            onDerive={onDerive}
            onUpdate={onUpdate}
          />
        ))}
      </div>
    </div>
  );
};

export default NFTTree;