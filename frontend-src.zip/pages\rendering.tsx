import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/router';
import Header from '../components/Header';
import Footer from '../components/Footer';
import StageGallery from '../components/StageGallery';
import ProjectEntry from '../components/ProjectEntry';

const RenderingPage: React.FC = () => {
  const [projects, setProjects] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchProjects();
  }, []);

  const fetchProjects = async () => {
    try {
      setLoading(true);
      // 获取建模阶段的项目
      const response = await fetch('http://localhost:3001/api/projects?stage=modeling');
      const projectsData = await response.json();
      // 为每个项目获取NFT数量
      const projectsWithNFTs = await Promise.all(
        projectsData.map(async (project: any) => {
          try {
            const [designNFTs, modelingNFTs] = await Promise.all([
              fetch(`http://localhost:3001/api/nfts?project_id=${project.id}&stage=design`).then(r => r.json()),
              fetch(`http://localhost:3001/api/nfts?project_id=${project.id}&stage=modeling`).then(r => r.json())
            ]);
            return {
              ...project,
              nftCount: designNFTs.length + modelingNFTs.length
            };
          } catch (error) {
            console.error(`Error fetching NFTs for project ${project.id}:`, error);
            return { ...project, nftCount: 0 };
          }
        })
      );
      setProjects(projectsWithNFTs);
    } catch (error) {
      console.error('Error fetching projects:', error);
    } finally {
      setLoading(false);
    }
  };

  const router = useRouter();
  const items = projects.map((p: any) => ({
    id: p.id,
    title: p.title,
    description: p.description,
    assetUrl: p.image_url,
  }));

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <main className="container mx-auto px-4 py-8">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">渲染项目</h1>
          <p className="text-xl text-gray-600">
            查看和管理处于建模阶段的项目，继续派生和更新NFT
          </p>
        </div>

        {loading ? (
          <div className="flex justify-center items-center h-64">
            <div className="text-lg">加载中...</div>
          </div>
        ) : (
          <StageGallery
            title="渲染阶段入口"
            stage="rendering"
            items={items}
            onProjectClick={(item: any) => router.push(`/rendering/${item.id}`)}
          />
        )}

        {!loading && projects.length === 0 && (
          <div className="text-center py-12">
            <div className="text-gray-500 mb-4">
              <svg className="mx-auto h-12 w-12 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" />
              </svg>
            </div>
            <h3 className="text-lg font-medium text-gray-900 mb-2">暂无渲染项目</h3>
            <p className="text-gray-500">
              当建模项目完成后，它们将出现在这里进行渲染处理
            </p>
          </div>
        )}

        {/* 操作说明 */}
        <div className="mt-12 bg-blue-50 border border-blue-200 rounded-lg p-6">
          <h3 className="text-lg font-medium text-blue-900 mb-2">渲染阶段说明</h3>
          <ul className="text-blue-800 space-y-1 text-sm">
            <li>• 这里显示所有处于建模阶段的项目</li>
            <li>• 点击项目卡片可以进入详情页面查看NFT演化树</li>
            <li>• 在详情页面可以继续派生新的渲染NFT或更新现有NFT</li>
            <li>• 渲染NFT创建后，项目将进入首页展示</li>
          </ul>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default RenderingPage;