import React from 'react';

declare global {
  interface Window {
    ethereum?: any;
  }
}

interface ConnectWalletModalProps {
  open: boolean;
  onClose: () => void;
  onConnected: (account: string) => void;
}

const ConnectWalletModal: React.FC<ConnectWalletModalProps> = ({ open, onClose, onConnected }) => {
  const [connecting, setConnecting] = React.useState(false);
  const [message, setMessage] = React.useState<string>('');

  if (!open) return null;

  const handleConnect = async () => {
    setMessage('');
    try {
      if (!window.ethereum) {
        setMessage('未检测到 MetaMask。请先安装浏览器扩展。');
        return;
      }
      setConnecting(true);
      const accounts: string[] = await window.ethereum.request({ method: 'eth_requestAccounts' });
      if (accounts && accounts.length > 0) {
        onConnected(accounts[0]);
        setMessage('连接成功');
        onClose();
      } else {
        setMessage('未获取到账户信息');
      }
    } catch (err: any) {
      setMessage(err?.message || '连接失败，请重试');
    } finally {
      setConnecting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />
      <div className="absolute inset-0 flex items-center justify-center p-4">
        <div className="w-full max-w-md rounded-2xl bg-white shadow-xl">
          <div className="px-6 py-5 border-b">
            <h3 className="text-lg font-semibold">连接钱包</h3>
            <p className="mt-1 text-sm text-gray-600">使用 MetaMask 连接以进行链上交互。</p>
          </div>
          <div className="px-6 py-5">
            {!!message && <p className="mb-3 text-sm text-gray-700">{message}</p>}
            {!window.ethereum && (
              <p className="mb-3 text-sm text-red-600">未检测到 MetaMask。请安装后重试。</p>
            )}
            <button
              className="w-full px-4 py-2 rounded-md bg-indigo-600 text-white hover:bg-indigo-700 disabled:opacity-50"
              onClick={handleConnect}
              disabled={connecting}
            >
              {connecting ? '正在连接...' : '连接 MetaMask'}
            </button>
            {!window.ethereum && (
              <a
                className="mt-3 inline-block text-sm text-indigo-600 hover:text-indigo-700"
                href="https://metamask.io/download/"
                target="_blank"
                rel="noreferrer"
              >
                安装 MetaMask
              </a>
            )}
          </div>
          <div className="px-6 py-4 border-t flex justify-end">
            <button className="px-3 py-1.5 text-sm rounded-md bg-gray-100 hover:bg-gray-200" onClick={onClose}>关闭</button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ConnectWalletModal;