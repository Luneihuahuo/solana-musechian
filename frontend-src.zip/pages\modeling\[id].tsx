import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/router';
import Header from '../../components/Header';
import Footer from '../../components/Footer';
import NFTTree from '../../components/NFTTree';

const ModelingDetailPage: React.FC = () => {
  const router = useRouter();
  const { id } = router.query;
  const [project, setProject] = useState<any>(null);
  const [allNFTs, setAllNFTs] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (id) {
      fetchProjectData();
    }
  }, [id]);

  const fetchProjectData = async () => {
    try {
      setLoading(true);
      
      // 获取设计项目信息
      const projectResponse = await fetch(`http://localhost:3001/api/projects/${id}`);
      const projectData = await projectResponse.json();
      setProject(projectData);

      // 获取该项目的所有NFT（设计和建模阶段）
      const [designNFTs, modelingNFTs] = await Promise.all([
        fetch(`http://localhost:3001/api/nfts?project_id=${id}&stage=design`).then(r => r.json()),
        fetch(`http://localhost:3001/api/nfts?project_id=${id}&stage=modeling`).then(r => r.json())
      ]);
      
      setAllNFTs([...designNFTs, ...modelingNFTs]);
    } catch (error) {
      console.error('Error fetching project data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleBack = () => {
    router.push('/modeling');
  };

  const handleRefresh = () => {
    fetchProjectData();
  };

  const handleNFTDerive = async (nft: any) => {
    const title = prompt('请输入新NFT的标题:', `${nft.title} - 建模版本`);
    const imageUrl = prompt('请输入新NFT的图片URL:');
    
    if (!title || !imageUrl) return;

    try {
      const response = await fetch('http://localhost:3001/api/nfts', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          title,
          description: `基于"${nft.title}"派生的建模NFT`,
          image_url: imageUrl,
          stage: 'modeling',
          project_id: id,
          parent_id: nft.id,
          creator: 'current_user'
        }),
      });

      if (response.ok) {
        alert('建模NFT创建成功！');
        await fetchProjectData();
        
        // 保持旧版：必要时仅更新阶段为 modeling，不进行跨页跳转
        if (project.stage === 'design') {
          await fetch(`http://localhost:3001/api/projects/${id}`, {
            method: 'PUT',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({
              ...project,
              stage: 'modeling'
            }),
          });
        }
      } else {
        alert('派生失败，请重试');
      }
    } catch (error) {
      console.error('Error deriving NFT:', error);
      alert('派生失败，请重试');
    }
  };

  const handleNFTUpdate = async (nft: any) => {
    const newImageUrl = prompt('请输入新的图片URL:', nft.image_url);
    if (!newImageUrl || newImageUrl === nft.image_url) return;

    try {
      const response = await fetch(`http://localhost:3001/api/nfts/${nft.id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          ...nft,
          image_url: newImageUrl
        }),
      });

      if (response.ok) {
        alert('NFT更新成功！');
        fetchProjectData();
      } else {
        alert('更新失败，请重试');
      }
    } catch (error) {
      console.error('Error updating NFT:', error);
      alert('更新失败，请重试');
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header />
        <div className="flex justify-center items-center h-64">
          <div className="text-lg">加载中...</div>
        </div>
        <Footer />
      </div>
    );
  }

  if (!project) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header />
        <div className="flex justify-center items-center h-64">
          <div className="text-lg text-red-500">项目未找到</div>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <main className="container mx-auto px-4 py-8">
        {/* 导航栏 */}
        <div className="flex justify-between items-center mb-8">
          <button
            onClick={handleBack}
            className="flex items-center space-x-2 text-blue-600 hover:text-blue-800"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
            <span>返回建模页面</span>
          </button>
          <button
            onClick={handleRefresh}
            className="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors"
          >
            刷新
          </button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* 左侧：项目信息 */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-lg shadow-lg p-6">
              <h2 className="text-xl font-bold text-gray-800 mb-4">项目信息</h2>
              <img
                src={project.image_url || '/images/placeholder.png'}
                alt={project.title}
                className="w-full h-32 object-cover rounded-lg mb-4"
              />
              <h3 className="text-lg font-semibold text-gray-800 mb-2">{project.title}</h3>
              <p className="text-gray-600 mb-4 text-sm">{project.description}</p>
              <div className="space-y-2 text-sm text-gray-500">
                <div>创作者: {project.creator}</div>
                <div>当前阶段: {project.stage}</div>
                <div>创建时间: {new Date(project.created_at).toLocaleDateString()}</div>
              </div>
            </div>

            {/* 统计信息 */}
            <div className="bg-white rounded-lg shadow-lg p-6 mt-6">
              <h3 className="text-lg font-semibold text-gray-800 mb-4">NFT统计</h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span>设计NFT:</span>
                  <span className="font-semibold text-blue-600">
                    {allNFTs.filter(nft => nft.stage === 'design').length}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span>建模NFT:</span>
                  <span className="font-semibold text-green-600">
                    {allNFTs.filter(nft => nft.stage === 'modeling').length}
                  </span>
                </div>
                <div className="flex justify-between border-t pt-2">
                  <span>总计:</span>
                  <span className="font-bold">{allNFTs.length}</span>
                </div>
              </div>
            </div>
          </div>

          {/* 右侧：NFT演化树 */}
          <div className="lg:col-span-3">
            <div className="bg-white rounded-lg shadow-lg p-6">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-xl font-bold text-gray-800">NFT演化树</h2>
                <div className="text-sm text-gray-500">
                  点击NFT可查看详情，使用"派生"和"更新"按钮进行操作
                </div>
              </div>
              
              {allNFTs.length === 0 ? (
                <div className="text-center py-12 text-gray-500">
                  <p>该项目还没有NFT</p>
                  <p className="text-sm mt-2">请先在设计页面创建设计NFT</p>
                </div>
              ) : (
                <NFTTree
                  nfts={allNFTs}
                  onDerive={handleNFTDerive}
                  onUpdate={handleNFTUpdate}
                />
              )}
            </div>
          </div>
        </div>

        {/* 操作说明 */}
        <div className="mt-8 bg-blue-50 border border-blue-200 rounded-lg p-6">
          <h3 className="text-lg font-medium text-blue-900 mb-2">建模阶段说明</h3>
          <ul className="text-blue-800 space-y-1 text-sm">
            <li>• 在这里可以查看项目的完整NFT演化树，包括设计和建模阶段的所有NFT</li>
            <li>• 点击任意NFT的"派生"按钮可以创建新的建模NFT</li>
            <li>• 点击"更新"按钮可以修改现有NFT的图片</li>
            <li>• 建模NFT创建后，项目将进入渲染阶段</li>
          </ul>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default ModelingDetailPage;