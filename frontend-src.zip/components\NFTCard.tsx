import React from 'react';

interface NFTCardProps {
    id?: string;
    imageUrl: string;
    title: string;
    description: string;
    onClick?: () => void;
}

const NFTCard: React.FC<NFTCardProps> = ({ id, imageUrl, title, description, onClick }) => {
    // 使用外部占位图，防止本地图片缺失导致加载失败
    const defaultImage = 'https://placehold.co/600x400/png';
    
    const handleImageError = (e: React.SyntheticEvent<HTMLImageElement, Event>) => {
        const target = e.target as HTMLImageElement;
        target.src = defaultImage;
    };
    
    return (
        <div className="nft-card" onClick={onClick}>
            <img 
                src={imageUrl || defaultImage} 
                alt={title} 
                className="nft-image" 
                onError={handleImageError}
            />
            <h3 className="nft-title">{title}</h3>
            <p className="nft-description">{description}</p>
            {id && <p className="nft-id">ID: {id}</p>}
        </div>
    );
};

export default NFTCard;