import type { NextApiRequest, NextApiResponse } from 'next';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const { id } = req.query;
  const base = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5000';

  try {
    const r = await fetch(`${base}/api/onchain/nft/${id}`);
    const ct = r.headers.get('content-type') || '';
    if (!r.ok || !ct.includes('application/json')) throw new Error(`Bad response ${r.status}`);
    const data = await r.json();
    return res.status(200).json(data);
  } catch (err) {
    const sample = {
      id,
      name: `NFT #${id}`,
      description: 'Local sample metadata (backend unreachable).',
      image: '/images/sample.png',
      attributes: [
        { trait_type: 'Version', value: '2' },
        { trait_type: 'Quality', value: 'High' }
      ]
    };
    return res.status(200).json(sample);
  }
}