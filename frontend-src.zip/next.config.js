module.exports = {
  reactStrictMode: true,
  turbopack: {},
  images: {
    domains: ['example.com', 'localhost'], // Replace with your image domains
  },
  webpack: (config) => {
    // Custom webpack configuration
    return config;
  },
};