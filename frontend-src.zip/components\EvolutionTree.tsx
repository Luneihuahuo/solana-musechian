import React from 'react';

export interface EvolutionNode {
  id: string;
  parentId: string | null;
  stage: 'inspiration' | 'design' | 'modeling' | 'rendering';
  title: string;
  description: string;
  actor: { address: string; name: string };
  timestamp: string;
  assetUrl?: string;
  tx?: string;
  children?: EvolutionNode[];
}

const stageClass: Record<EvolutionNode['stage'], string> = {
  inspiration: 'bg-yellow-100 text-yellow-800',
  design: 'bg-blue-100 text-blue-800',
  modeling: 'bg-purple-100 text-purple-800',
  rendering: 'bg-green-100 text-green-800',
};

const NodeItem: React.FC<{ node: EvolutionNode; depth?: number }> = ({ node, depth = 0 }) => {
  const [open, setOpen] = React.useState(true);
  const hasChildren = (node.children || []).length > 0;
  const paddingLeft = depth * 16; // 16px per depth

  return (
    <div style={{ paddingLeft }} className="relative">
      {/* Connector line */}
      {depth > 0 && (
        <span className="absolute -left-2 top-4 w-2 h-0.5 bg-gray-300" />
      )}
      <div className="rounded-lg border p-3 bg-white">
        <div className="flex items-center justify-between">
          <span className={`inline-flex items-center px-2 py-1 rounded ${stageClass[node.stage]}`}>{node.stage}</span>
          <span className="text-xs text-gray-500">{new Date(node.timestamp).toLocaleString()}</span>
        </div>
        <div className="mt-1 flex items-start justify-between gap-3">
          <div className="flex-1">
            <h3 className="text-sm font-semibold">{node.title}</h3>
            <p className="mt-1 text-sm text-gray-700">{node.description}</p>
            <p className="mt-1 text-xs text-gray-600">参与者：{node.actor?.name}（{node.actor?.address}）</p>
            {!!node.tx && <p className="mt-1 text-[11px] text-gray-500">Tx: {node.tx}</p>}
          </div>
          {hasChildren && (
            <button
              className="shrink-0 inline-flex items-center rounded-md bg-gray-100 text-gray-800 px-2 py-1 text-xs hover:bg-gray-200"
              onClick={() => setOpen((v) => !v)}
            >
              {open ? '折叠' : '展开'}
            </button>
          )}
        </div>
        {!!node.assetUrl && (
          <img className="mt-2 w-full rounded" src={node.assetUrl} alt={node.title} />
        )}
      </div>
      {hasChildren && open && (
        <div className="mt-2 space-y-2">
          {node.children!.map((child) => (
            <NodeItem key={child.id} node={child} depth={depth + 1} />
          ))}
        </div>
      )}
    </div>
  );
};

const EvolutionTree: React.FC<{ root: EvolutionNode | null }> = ({ root }) => {
  if (!root) return <p className="text-gray-600">暂无树状演化数据。</p>;
  return (
    <div className="space-y-2">
      <NodeItem node={root} depth={0} />
    </div>
  );
};

export default EvolutionTree;