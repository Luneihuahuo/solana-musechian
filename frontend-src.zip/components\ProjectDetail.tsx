import React, { useState, useEffect } from 'react';
import EvolutionTree, { EvolutionNode } from './EvolutionTree';
import { deriveChildNFT, updateNFTMetadata } from '../services/api';

interface ProjectDetailProps {
  project: any;
  stage: 'inspiration' | 'design' | 'modeling' | 'rendering';
  onBack: () => void;
  onRefresh?: () => void;
}

export const ProjectDetail: React.FC<ProjectDetailProps> = ({ 
  project, 
  stage, 
  onBack, 
  onRefresh 
}) => {
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    image: '',
    attributes: []
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [message, setMessage] = useState('');
  const [evolutionData, setEvolutionData] = useState<EvolutionNode | null>(null);

  // 获取进化树数据
  useEffect(() => {
    const loadEvolutionData = async () => {
      try {
        // 这里可以调用获取进化树的API
        // 暂时使用项目数据作为根节点
        const root: EvolutionNode = {
          id: String(project.id),
          parentId: null,
          stage: project.stage,
          title: project.name || '项目',
          description: project.description || '',
          actor: { address: 'unknown', name: 'unknown' },
          timestamp: new Date().toISOString(),
          assetUrl: project.image,
          tx: undefined,
          children: [],
        };
        setEvolutionData(root);
      } catch (error) {
        console.error('Failed to load evolution data:', error);
      }
    };

    if (project) {
      loadEvolutionData();
    }
  }, [project]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleDerive = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setMessage('');

    try {
      const nextStage = getNextStage(stage);
      if (!nextStage) {
        throw new Error('无法确定下一阶段');
      }

      await deriveChildNFT(
        String(project.id),
        nextStage as 'design' | 'modeling' | 'rendering',
        {
          ownerAddress: 'demo-address', // 实际应该从钱包获取
          metadata: {
            name: formData.name,
            description: formData.description,
            image: formData.image,
            attributes: formData.attributes
          },
          uri: `ipfs://demo-${Date.now()}`,
        }
      );

      setMessage(`成功派生${getStageDisplayName(nextStage)}NFT！`);
      setFormData({ name: '', description: '', image: '', attributes: [] });
      
      if (onRefresh) {
        onRefresh();
      }
    } catch (error: any) {
      setMessage(`派生失败: ${error.message}`);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleUpdate = async () => {
    setIsSubmitting(true);
    setMessage('');

    try {
      await updateNFTMetadata(String(project.id), {
        name: formData.name || project.name,
        description: formData.description || project.description,
        image: formData.image || project.image,
        attributes: formData.attributes.length > 0 ? formData.attributes : project.attributes
      });

      setMessage('成功更新NFT元数据！');
      
      if (onRefresh) {
        onRefresh();
      }
    } catch (error: any) {
      setMessage(`更新失败: ${error.message}`);
    } finally {
      setIsSubmitting(false);
    }
  };

  const getNextStage = (currentStage: string) => {
    const stageMap: { [key: string]: string } = {
      inspiration: 'design',
      design: 'modeling',
      modeling: 'rendering',
    };
    return stageMap[currentStage];
  };

  const getStageDisplayName = (stage: string) => {
    const displayMap: { [key: string]: string } = {
      inspiration: '灵感',
      design: '设计',
      modeling: '建模',
      rendering: '渲染',
    };
    return displayMap[stage] || stage;
  };

  const nextStage = getNextStage(stage);

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* 返回按钮 */}
        <div className="mb-6">
          <button
            onClick={onBack}
            className="flex items-center text-blue-600 hover:text-blue-800 transition-colors"
          >
            <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
            返回{getStageDisplayName(stage)}列表
          </button>
        </div>

        {/* 项目标题 */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">{project.name}</h1>
          <p className="text-gray-600">{project.description}</p>
          <div className="mt-4 flex items-center space-x-4">
            <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-blue-100 text-blue-800">
              {getStageDisplayName(stage)}阶段
            </span>
            <span className="text-sm text-gray-500">ID: {project.id}</span>
          </div>
        </div>

        {/* 主要内容区域 - 并列布局 */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* 左侧：派生/更新表单 */}
          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex space-x-4 mb-6">
              {nextStage && (
                <h2 className="text-xl font-semibold text-gray-900 flex-1">
                  派生{getStageDisplayName(nextStage)}NFT
                </h2>
              )}
              <h2 className="text-xl font-semibold text-gray-900 flex-1">
                更新当前NFT
              </h2>
            </div>

            <form onSubmit={handleDerive} className="space-y-4">
              <div>
                <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">
                  名称
                </label>
                <input
                  type="text"
                  id="name"
                  name="name"
                  value={formData.name}
                  onChange={handleInputChange}
                  placeholder={project.name}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div>
                <label htmlFor="description" className="block text-sm font-medium text-gray-700 mb-1">
                  描述
                </label>
                <textarea
                  id="description"
                  name="description"
                  value={formData.description}
                  onChange={handleInputChange}
                  placeholder={project.description}
                  rows={3}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div>
                <label htmlFor="image" className="block text-sm font-medium text-gray-700 mb-1">
                  图片URL
                </label>
                <input
                  type="url"
                  id="image"
                  name="image"
                  value={formData.image}
                  onChange={handleInputChange}
                  placeholder={project.image}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              {/* 操作按钮 */}
              <div className="flex space-x-4 pt-4">
                {nextStage && (
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="flex-1 bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                  >
                    {isSubmitting ? '派生中...' : `派生${getStageDisplayName(nextStage)}`}
                  </button>
                )}
                
                <button
                  type="button"
                  onClick={handleUpdate}
                  disabled={isSubmitting}
                  className="flex-1 bg-green-600 text-white py-2 px-4 rounded-md hover:bg-green-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                >
                  {isSubmitting ? '更新中...' : '更新NFT'}
                </button>
              </div>
            </form>

            {/* 状态消息 */}
            {message && (
              <div className={`mt-4 p-3 rounded-md ${
                message.includes('成功') 
                  ? 'bg-green-100 text-green-800' 
                  : 'bg-red-100 text-red-800'
              }`}>
                {message}
              </div>
            )}
          </div>

          {/* 右侧：进化树状图 */}
          <div className="bg-white rounded-lg shadow-md p-6">
            <h2 className="text-xl font-semibold text-gray-900 mb-6">进化树状图</h2>
            
            {evolutionData ? (
              <div className="h-96 border border-gray-200 rounded-md overflow-hidden">
                <EvolutionTree root={evolutionData} />
              </div>
            ) : (
              <div className="h-96 border border-gray-200 rounded-md flex items-center justify-center">
                <div className="text-center text-gray-500">
                  <svg className="w-12 h-12 mx-auto mb-4 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" />
                  </svg>
                  <p>加载进化树数据中...</p>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};