import React, { useEffect, useState } from 'react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import { createProject, listProjects } from '../services/api';

const InspirationPage = () => {
    const [projects, setProjects] = useState<any[]>([]);
    const [ownerAddress, setOwnerAddress] = useState('alice');
    const [title, setTitle] = useState('初始灵感');
    const [description, setDescription] = useState('一个关于未来城市的构想');
    const [uri, setUri] = useState('ipfs://FAKE_HASH_1');
    const [submitting, setSubmitting] = useState(false);
    const [msg, setMsg] = useState('');

    useEffect(() => {
        const load = async () => {
            const r = await listProjects();
            setProjects(r.items || []);
        };
        load();
    }, []);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setSubmitting(true);
        setMsg('');
        const payload = { ownerAddress, uri, metadata: { title, description } };
        const r = await createProject(payload);
        if (r?.success) {
            setMsg('已创建灵感项目并上链记录（含确权/溯源）');
            const refresh = await listProjects();
            setProjects(refresh.items || []);
        } else {
            setMsg('提交失败：' + (r?.error || '未知错误'));
        }
        setSubmitting(false);
    };

    return (
        <div>
            <Header />
            <main className="max-w-6xl mx-auto px-4 py-8">
                <h1 className="text-2xl font-bold">灵感阶段</h1>
                <p className="mt-2 text-gray-700">创建灵感项目并在此页面展示，提交将铸造根NFT并记录溯源。</p>

                <form onSubmit={handleSubmit} className="mt-6 space-y-3">
                    <div>
                        <label className="block text-sm text-gray-600">Owner Address</label>
                        <input value={ownerAddress} onChange={(e) => setOwnerAddress(e.target.value)} className="border rounded px-3 py-2 w-full" />
                    </div>
                    <div>
                        <label className="block text-sm text-gray-600">Title</label>
                        <input value={title} onChange={(e) => setTitle(e.target.value)} className="border rounded px-3 py-2 w-full" />
                    </div>
                    <div>
                        <label className="block text-sm text-gray-600">Description</label>
                        <textarea value={description} onChange={(e) => setDescription(e.target.value)} className="border rounded px-3 py-2 w-full" />
                    </div>
                    <div>
                        <label className="block text-sm text-gray-600">Metadata URI（可直接传 ipfs://）</label>
                        <input value={uri} onChange={(e) => setUri(e.target.value)} className="border rounded px-3 py-2 w-full" />
                    </div>
                    <button type="submit" disabled={submitting} className="px-4 py-2 rounded bg-blue-600 text-white">
                        {submitting ? '提交中...' : '创建灵感项目并提交'}
                    </button>
                    {msg && <p className="text-sm text-gray-600">{msg}</p>}
                </form>

                <h2 className="mt-10 text-xl font-semibold">灵感项目列表</h2>
                <ul className="mt-4 space-y-4">
                    {projects.map((item: any, idx: number) => (
                        <li key={item.id || idx} className="rounded border p-4">
                            <div className="flex items-center justify-between">
                                <span className="inline-flex px-2 py-1 rounded bg-yellow-100 text-yellow-800">inspiration</span>
                                <span className="text-sm text-gray-500">{new Date(item.timestamp || Date.now()).toLocaleString()}</span>
                            </div>
                            <h3 className="mt-2 text-lg font-medium">{item.title || item.metadata?.title || '未命名灵感'}</h3>
                            <p className="mt-1 text-gray-700">{item.description || item.metadata?.description || ''}</p>
                            <p className="mt-1 text-sm text-gray-600">参与者：{item.actor?.name || item.ownerAddress || 'unknown'}（{item.actor?.address || item.ownerAddress || 'unknown'}）</p>
                            {item.tx && <p className="mt-2 text-xs text-gray-500">Tx: {item.tx}</p>}
                            <a href={`/nft/${item.id}`} className="mt-3 inline-flex items-center text-sm text-indigo-600 hover:text-indigo-700">查看详情</a>
                        </li>
                    ))}
                    {projects.length === 0 && (
                        <p className="text-gray-600">暂无灵感项目。</p>
                    )}
                </ul>
            </main>
            <Footer />
        </div>
    );
};

export default InspirationPage;