import React from 'react';
import { useRouter } from 'next/router';

interface ProjectEntryProps {
  project: any;
  stage: 'design' | 'modeling' | 'rendering';
  showNFTCount?: boolean;
  nftCount?: number;
}

const ProjectEntry: React.FC<ProjectEntryProps> = ({ 
  project, 
  stage, 
  showNFTCount = false, 
  nftCount = 0 
}) => {
  const router = useRouter();

  const handleClick = () => {
    router.push(`/${stage}/${project.id}`);
  };

  const getStageTitle = () => {
    switch (stage) {
      case 'design':
        return '设计阶段';
      case 'modeling':
        return '建模阶段';
      case 'rendering':
        return '渲染阶段';
      default:
        return '';
    }
  };

  const getStageDescription = () => {
    switch (stage) {
      case 'design':
        return '点击进入派生设计NFT并提交作品';
      case 'modeling':
        return '查看NFT树状图，继续派生和更新';
      case 'rendering':
        return '查看NFT树状图，继续派生和更新';
      default:
        return '';
    }
  };

  return (
    <div 
      className="bg-white rounded-lg shadow-lg p-6 cursor-pointer hover:shadow-xl transition-shadow duration-300 border-2 border-gray-200 hover:border-blue-400"
      onClick={handleClick}
    >
      {/* 项目预览图 */}
      <div className="relative mb-4">
        <img
          src={project.image_url || '/images/placeholder.png'}
          alt={project.title}
          className="w-full h-48 object-cover rounded-lg"
        />
        <div className="absolute top-2 right-2 bg-blue-500 text-white px-2 py-1 rounded-full text-sm">
          {getStageTitle()}
        </div>
        {showNFTCount && (
          <div className="absolute bottom-2 left-2 bg-green-500 text-white px-2 py-1 rounded-full text-sm">
            NFT数量: {nftCount}
          </div>
        )}
      </div>

      {/* 项目信息 */}
      <div className="space-y-2">
        <h3 className="text-xl font-bold text-gray-800 truncate">
          {project.title}
        </h3>
        <p className="text-gray-600 text-sm line-clamp-2">
          {project.description}
        </p>
        <div className="flex justify-between items-center text-sm text-gray-500">
          <span>创作者: {project.creator}</span>
          <span>{new Date(project.created_at).toLocaleDateString()}</span>
        </div>
      </div>

      {/* 操作提示 */}
      <div className="mt-4 p-3 bg-gray-50 rounded-lg">
        <p className="text-sm text-gray-700 text-center">
          {getStageDescription()}
        </p>
        <div className="flex justify-center mt-2">
          <svg 
            className="w-6 h-6 text-blue-500" 
            fill="none" 
            stroke="currentColor" 
            viewBox="0 0 24 24"
          >
            <path 
              strokeLinecap="round" 
              strokeLinejoin="round" 
              strokeWidth={2} 
              d="M13 7l5 5m0 0l-5 5m5-5H6" 
            />
          </svg>
        </div>
      </div>
    </div>
  );
};

export default ProjectEntry;