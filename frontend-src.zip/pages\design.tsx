import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/router';
import Header from '../components/Header';
import Footer from '../components/Footer';
import StageGallery from '../components/StageGallery';
import { listByStage } from '../services/api';

const DesignPage: React.FC = () => {
  const [inspirationProjects, setInspirationProjects] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchInspirationProjects();
  }, []);

  const router = useRouter();

  const fetchInspirationProjects = async () => {
    try {
      setLoading(true);
      // 改为使用站内 API 路由，避免跨域与端口问题
      const result = await listByStage('inspiration');
      setInspirationProjects(result.items || []);
    } catch (error) {
      console.error('Error fetching inspiration projects:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleRefresh = () => {
    fetchInspirationProjects();
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header />
        <div className="flex justify-center items-center h-64">
          <div className="text-lg">加载中...</div>
        </div>
        <Footer />
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <main className="container mx-auto px-4 py-8">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-800">设计阶段</h1>
            <p className="text-gray-600 mt-2">
              选择灵感项目，进入设计详情页派生/更新NFT
            </p>
          </div>
          <button
            onClick={fetchInspirationProjects}
            className="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors"
          >
            刷新
          </button>
        </div>

        {loading ? (
          <div className="flex justify-center items-center h-64">
            <div className="text-lg">加载中...</div>
          </div>
        ) : inspirationProjects.length === 0 ? (
          <div className="text-center py-12">
            <div className="text-gray-500 text-lg">暂无灵感项目</div>
            <p className="text-gray-400 mt-2">请在首页或灵感页提交创意</p>
          </div>
        ) : (
          <StageGallery
            title="设计阶段入口"
            stage="design"
            items={inspirationProjects}
            onProjectClick={(item: any) => router.push(`/design/${item.id}`)}
          />
        )}
      </main>
      <Footer />
    </div>
  );
};

export default DesignPage;