import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/router';
import Header from '../../components/Header';
import Footer from '../../components/Footer';
import NFTTree from '../../components/NFTTree';
import { listByStage, getNFTEvolutionTree, deriveChildNFT, updateNFTMetadata } from '../../services/api';

const DesignDetailPage: React.FC = () => {
  const router = useRouter();
  const { id } = router.query;
  const [project, setProject] = useState<any>(null);
  const [designNFTs, setDesignNFTs] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showDeriveForm, setShowDeriveForm] = useState(false);
  const [deriveFormData, setDeriveFormData] = useState({
    title: '',
    description: '',
    image_url: ''
  });
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (id) {
      fetchProjectData();
    }
  }, [id]);

  const flattenToNodes = (root: any) => {
    const nodes: any[] = [];
    const visit = (n: any) => {
      nodes.push({
        id: n.id,
        title: n.title || `NFT ${n.id}`,
        image_url: n.assetUrl || n.metadata?.image || '/images/sample.png',
        stage: n.stage,
        created_at: n.timestamp || new Date().toISOString(),
        parent_id: n.parentId || undefined,
      });
      (n.children || []).forEach(visit);
    };
    if (root) visit(root);
    return nodes.filter((x) => x.stage !== 'inspiration');
  };

  const fetchProjectData = async () => {
    try {
      setLoading(true);
      // 使用站内 API 获取灵感项目信息
      const list = await listByStage('inspiration');
      const proj = (list.items || []).find((p: any) => String(p.id) === String(id));
      if (proj) {
        setProject({
          id: proj.id,
          title: proj.title,
          description: proj.description ?? '',
          image_url: proj.assetUrl || proj.metadata?.image || '/images/placeholder.png',
          creator: proj.actor?.name || proj.actor?.address || 'unknown',
          created_at: proj.timestamp,
          stage: proj.stage,
        });
      } else {
        setProject(null);
      }

      // 使用站内 API 获取演化树并映射为 NFTTree 需要的节点数组
      const t = await getNFTEvolutionTree(String(id));
      const root = (t && (t.tree || t.root)) || null;
      setDesignNFTs(flattenToNodes(root));
    } catch (error) {
      console.error('Error fetching project data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleBack = () => {
    router.push('/design');
  };

  const handleRefresh = () => {
    fetchProjectData();
  };

  const handleDeriveFromInspiration = () => {
    setShowDeriveForm(true);
    setDeriveFormData({
      title: `${project?.title || ''} - 设计版本`,
      description: `基于灵感项目"${project?.title || ''}"派生的设计NFT`,
      image_url: ''
    });
  };

  const handleSubmitDerive = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!deriveFormData.title.trim() || !deriveFormData.image_url.trim()) {
      alert('请填写标题和图片URL');
      return;
    }

    try {
      setSubmitting(true);
      const res = await deriveChildNFT(String(id), 'design', {
        ownerAddress: 'current_user',
        metadata: {
          name: deriveFormData.title,
          title: deriveFormData.title,
          description: deriveFormData.description,
          image: deriveFormData.image_url,
        },
      });

      if (res && res.success !== false) {
        alert('设计NFT创建成功！');
        setShowDeriveForm(false);
        setDeriveFormData({ title: '', description: '', image_url: '' });
        await fetchProjectData();
      } else {
        alert('创建失败，请重试');
      }
    } catch (error) {
      console.error('Error creating design NFT:', error);
      alert('创建失败，请重试');
    } finally {
      setSubmitting(false);
    }
  };

  const handleNFTDerive = async (nft: any) => {
    const title = prompt('请输入新NFT的标题:', `${nft.title} - 派生版本`);
    const imageUrl = prompt('请输入新NFT的图片URL:');
    if (!title || !imageUrl) return;

    try {
      const res = await deriveChildNFT(String(nft.id), 'design', {
        ownerAddress: 'current_user',
        metadata: { name: title, title, description: `基于"${nft.title}"派生的设计NFT`, image: imageUrl },
      });
      if (res && res.success !== false) {
        alert('派生NFT创建成功！');
        fetchProjectData();
      } else {
        alert('派生失败，请重试');
      }
    } catch (error) {
      console.error('Error deriving NFT:', error);
      alert('派生失败，请重试');
    }
  };

  const handleNFTUpdate = async (nft: any) => {
    const newImageUrl = prompt('请输入新的图片URL:', nft.image_url);
    if (!newImageUrl || newImageUrl === nft.image_url) return;

    try {
      const res = await updateNFTMetadata(String(nft.id), { image: newImageUrl });
      if (res && res.success !== false) {
        alert('NFT更新成功！');
        fetchProjectData();
      } else {
        alert('更新失败，请重试');
      }
    } catch (error) {
      console.error('Error updating NFT:', error);
      alert('更新失败，请重试');
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header />
        <div className="flex justify-center items-center h-64">
          <div className="text-lg">加载中...</div>
        </div>
        <Footer />
      </div>
    );
  }

  if (!project) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header />
        <div className="flex justify-center items-center h-64">
          <div className="text-lg text-red-500">项目未找到</div>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <main className="container mx-auto px-4 py-8">
        {/* 导航栏 */}
        <div className="flex justify-between items-center mb-8">
          <button
            onClick={handleBack}
            className="flex items-center space-x-2 text-blue-600 hover:text-blue-800"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
            <span>返回设计页面</span>
          </button>
          <button
            onClick={handleRefresh}
            className="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors"
          >
            刷新
          </button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* 左侧：灵感项目信息 */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-lg shadow-lg p-6">
              <h2 className="text-xl font-bold text-gray-800 mb-4">灵感项目</h2>
              <img
                src={project.image_url || '/images/placeholder.png'}
                alt={project.title}
                className="w-full h-48 object-cover rounded-lg mb-4"
              />
              <h3 className="text-lg font-semibold text-gray-800 mb-2">{project.title}</h3>
              <p className="text-gray-600 mb-4">{project.description}</p>
              <div className="space-y-2 text-sm text-gray-500">
                <div>创作者: {project.creator}</div>
                <div>创建时间: {new Date(project.created_at).toLocaleString()}</div>
                <div>阶段: {project.stage}</div>
              </div>
              
              {/* 派生设计NFT按钮 */}
              <button
                onClick={handleDeriveFromInspiration}
                className="w-full mt-6 px-4 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600 transition-colors"
              >
                派生设计NFT
              </button>
            </div>
          </div>

          {/* 右侧：设计NFT树状图 */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-lg shadow-lg p-6">
              <h2 className="text-xl font-bold text-gray-800 mb-4">设计NFT演化树</h2>
              {designNFTs.length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  <p>还没有派生的设计NFT</p>
                  <p className="text-sm mt-2">点击左侧"派生设计NFT"开始创作</p>
                </div>
              ) : (
                <NFTTree
                  nfts={designNFTs}
                  onDerive={handleNFTDerive}
                  onUpdate={handleNFTUpdate}
                />
              )}
            </div>
          </div>
        </div>

        {/* 派生表单模态框 */}
        {showDeriveForm && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white rounded-lg p-6 w-full max-w-md">
              <h3 className="text-lg font-semibold mb-4">派生设计NFT</h3>
              <form onSubmit={handleSubmitDerive}>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      标题
                    </label>
                    <input
                      type="text"
                      value={deriveFormData.title}
                      onChange={(e) => setDeriveFormData({...deriveFormData, title: e.target.value})}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      描述
                    </label>
                    <textarea
                      value={deriveFormData.description}
                      onChange={(e) => setDeriveFormData({...deriveFormData, description: e.target.value})}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                      rows={3}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      图片URL
                    </label>
                    <input
                      type="url"
                      value={deriveFormData.image_url}
                      onChange={(e) => setDeriveFormData({...deriveFormData, image_url: e.target.value})}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                      required
                    />
                  </div>
                </div>
                <div className="flex space-x-3 mt-6">
                  <button
                    type="button"
                    onClick={() => setShowDeriveForm(false)}
                    className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-md hover:bg-gray-50"
                  >
                    取消
                  </button>
                  <button
                    type="submit"
                    disabled={submitting}
                    className="flex-1 px-4 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600 disabled:opacity-50"
                  >
                    {submitting ? '创建中...' : '创建NFT'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </main>
      <Footer />
    </div>
  );
};

export default DesignDetailPage;